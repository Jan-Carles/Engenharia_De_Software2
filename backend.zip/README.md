# Back-end – Peças de roupa (Backlog ID5)

1. `pip install -r requirements.txt`
2. Aplique o `schema.sql` no banco `engenharia2` (pgAdmin ou `psql`)
3. `uvicorn main:app --reload` → documentação interativa em http://localhost:8000/docs
4. Testes: `pytest -v` (limpa as tabelas! use um banco de teste: `DB_NAME=engenharia2_teste pytest -v`)

Conexão configurável por variáveis: DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD.

| Método | Rota | Função |
|---|---|---|
| POST | /pecas | Cadastrar (201 / 409 duplicada / 422 inválida) |
| GET | /pecas | Consultar com busca, categoria, genero, pagina, limite |
| GET | /pecas/{id} | Consultar uma peça |
| PUT | /pecas/{id} | Editar |
| DELETE | /pecas/{id} | Excluir |
| GET | /pecas/opcoes | Valores dos selects do formulário |
