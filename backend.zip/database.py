"""Conexão com o PostgreSQL (mesmos dados do conexao.py, mas configuráveis por variável de ambiente)."""
import os
from typing import Iterator

import psycopg
from psycopg.rows import dict_row


def _dsn() -> dict:
    return dict(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        dbname=os.getenv("DB_NAME", "engenharia2"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", "postgres"),
    )


def get_conn() -> Iterator[psycopg.Connection]:
    """Dependência do FastAPI: abre uma conexão por requisição.

    Ao sair do `with`, faz COMMIT se tudo deu certo ou ROLLBACK se houve exceção.
    """
    with psycopg.connect(**_dsn(), row_factory=dict_row) as conn:
        yield conn
